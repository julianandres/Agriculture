/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import java.util.List;
import org.bson.types.ObjectId;

/**
 *
 * @author ju
 */

public class Ciudad  {
   
  
    private ObjectId id;
    
    private int idciudad;
    
    private String nombre;
    
    private String pageweb;
  
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }
    
    
    public Ciudad() {
    }

    public Ciudad(int idciudad) {
        this.idciudad = idciudad;
    }

    public Ciudad(ObjectId id,int idciudad, String nombre, String pageweb) {
        this.id=id;
        this.idciudad = idciudad;
        this.nombre = nombre;
        this.pageweb = pageweb;
    }

    public int getIdciudad() {
        return idciudad;
    }

    public void setIdciudad(int idciudad) {
        this.idciudad = idciudad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPageweb() {
        return pageweb;
    }

    public void setPageweb(String pageweb) {
        this.pageweb = pageweb;
    }
}
