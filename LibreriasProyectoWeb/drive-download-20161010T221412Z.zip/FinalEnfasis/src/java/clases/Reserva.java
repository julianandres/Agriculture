
package clases;


/**
 *
 * @author ju
 */
public class Reserva {
    
    private int idreserva;
    private Vuelo idvuelo;
    private Cliente idcliente;
    public Reserva() {
    }

    public Reserva(int idreserva) {
        this.idreserva = idreserva;
    }

    public int getIdreserva() {
        return idreserva;
    }

    public void setIdreserva(int idreserva) {
        this.idreserva = idreserva;
    }

    public Vuelo getIdvuelo() {
        return idvuelo;
    }

    public void setIdvuelo(Vuelo idvuelo) {
        this.idvuelo = idvuelo;
    }

    public Cliente getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(Cliente idcliente) {
        this.idcliente = idcliente;
    }   
}