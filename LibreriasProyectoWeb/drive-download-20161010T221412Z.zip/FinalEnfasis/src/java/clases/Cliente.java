/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import java.util.List;

/**
 *
 * @author ju
 */

public class Cliente  {
   
    
    private int idcliente;
    
    private String nombres;
   
    private String apellidos;
    
    private String tipoid;
    
    private String id;
    
    private String login;
    
    private String password;
    

    public Cliente() {
        System.out.println("estoy creando un cliente");
    }

    public Cliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public Cliente(int idcliente, String nombres,String apellidos, String tipoid, String id, String login, String password) {
        this.apellidos=apellidos;
        this.idcliente = idcliente;
        this.nombres = nombres;
        this.tipoid = tipoid;
        this.id = id;
        this.login = login;
        this.password = password;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTipoid() {
        return tipoid;
    }

    public void setTipoid(String tipoid) {
        this.tipoid = tipoid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
