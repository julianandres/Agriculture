/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import org.bson.types.ObjectId;

/**
 *
 * @author ju
 */

public class Administrador {
   
    
   
    private ObjectId idadmin;
    
    private String nombres;
    
    private String apellidos;
   
    private String login;
    
    private String password;

    public Administrador() {
    }

    public ObjectId getIdadmin() {
        return idadmin;
    }

    public void setIdadmin(ObjectId idadmin) {
        this.idadmin = idadmin;
    }

   

    public Administrador( ObjectId idadmin,String nombres,String apellidos, String login, String password) {
        this.idadmin=idadmin;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.login = login;
        this.password = password;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }  
}
