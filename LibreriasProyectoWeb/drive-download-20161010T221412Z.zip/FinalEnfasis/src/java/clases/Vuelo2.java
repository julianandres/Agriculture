/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;


import java.util.List;

/**
 *
 * @author FredyMauricio
 */ 
public class Vuelo2 {
    private int idvuelo;
    private int codigo;
    private String fecha;
    private List<Reserva> reservaList;
    private int idciudest;
    private int idciudor;

    public int getIdciudest() {
        return idciudest;
    }

    public void setIdciudest(int idciudest) {
        this.idciudest = idciudest;
    }

    public int getIdciudor() {
        return idciudor;
    }

    public void setIdciudor(int idciudor) {
        this.idciudor = idciudor;
    }

    public Vuelo2() {
    }

    public Vuelo2(Short idvuelo) {
        this.idvuelo = idvuelo;
    }

    public Vuelo2(int idvuelo, int codigo, String fecha) {
        this.idvuelo = idvuelo;
        this.codigo = codigo;
        this.fecha = fecha;
    }

    public int getIdvuelo() {
        return idvuelo;
    }

    public void setIdvuelo(Short idvuelo) {
        this.idvuelo = idvuelo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public List<Reserva> getReservaList() {
        return reservaList;
    }

    public void setReservaList(List<Reserva> reservaList) {
        this.reservaList = reservaList;
    }

    
}
