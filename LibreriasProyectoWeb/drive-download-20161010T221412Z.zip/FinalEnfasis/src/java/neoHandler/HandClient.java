/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neoHandler;

import clases.Cliente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FredyMauricio
 */
public class HandClient {
    private String host;
    private int port;
    private Connection connection;
    
    public HandClient() {
        host = "localhost";
        port = 7474;
    }
    
    public HandClient(String h, int p) {
        host = h;
        port = p;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean connect(){
        try {
            Class.forName("org.neo4j.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:neo4j://localhost:7474");
            return true;
        } catch(ClassNotFoundException e) {
            System.out.println(e);
            return false;
        } catch(SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    //Cypher
    public ResultSet query(String cypher) {
        try {
            Statement stm = connection.createStatement();
            ResultSet res = stm.executeQuery(cypher);
            return res;
        } catch(SQLException e) {
            return null;
        }
    }
    
    public List<Cliente> loadClients() {
        List<Cliente> res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (c:Cliente) RETURN c.idcliente, c.nombres, c.apellidos, c.tipoid, c.id, c.login, c.password";
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    Cliente c;
                    c = new Cliente(rs.getInt("c.idcliente"), rs.getString("c.nombres"),
                            rs.getString("c.apellidos"),
                            rs.getString("c.tipoid"), 
                            rs.getString("c.id"),
                            rs.getString("c.login"),
                            rs.getString("c.password"));
                    res.add(c);
                }
                //System.out.println("FIN");
            } catch(SQLException e) {
                System.out.println(e);
            }
        }
        return res;
    }
    
    public void insertCliente(Cliente cliente) {
        if (connect()) {
            String cypher = "CREATE (c:Cliente {idcliente:"+asignarIdCliente()+","
                    + " nombres:'"+cliente.getNombres()+"',"
                    + " apellidos:'"+cliente.getApellidos()+"', "
                    + " tipoid:'"+cliente.getTipoid()+"',"
                    + " id:'"+cliente.getId()+"',"
                    + " login:'"+cliente.getLogin()+"',"
                    + " password:'"+cliente.getPassword()+"'})";
            query(cypher);
        }
    }
    
    public void updateCliente(Cliente cliente) {
        if (connect()) {
            String cypher = "MATCH (c:Cliente) WHERE c.idcliente="+cliente.getIdcliente()+" SET "
                    + " c.nombres='"+cliente.getNombres()+"',"
                    + " c.apellidos='"+cliente.getApellidos()+"', "
                    + " c.tipoid='"+cliente.getTipoid()+"',"
                    + " c.id='"+cliente.getId()+"',"
                    + " c.login='"+cliente.getLogin()+"',"
                    + " c.password='"+cliente.getPassword()+"'";
            query(cypher);
        }
    }
    
    public void deleteCliente(Cliente cliente) {
        if (connect()) {
            //Si hay relaciones entre nodos
            //MATCH (n { name: 'Andres' })-[r]-() DELETE n, r
            String cypher = "MATCH (c:Cliente) WHERE c.idcliente="+cliente.getIdcliente()+" DELETE c";
            query(cypher);
        }
    }
    public Cliente buscarCliPorId(Cliente cli){
        Cliente cliente = new Cliente();
        List<Cliente> res = new ArrayList();
       if (connect()) {
            String cypher = "MATCH (c:Cliente) WHERE c.idcliente="+cli.getIdcliente() +" RETURN c.idcliente, c.nombres, c.apellidos, c.tipoid, c.id, c.login, c.password";
             ResultSet rs;
            rs = query(cypher);
            try {
                while (rs.next()) {
                    Cliente c;
                    c = new Cliente(rs.getInt("c.idcliente"), rs.getString("c.nombres"),
                            rs.getString("c.apellidos"),
                            rs.getString("c.tipoid"), 
                            rs.getString("c.id"),
                            rs.getString("c.login"),
                            rs.getString("c.password"));
                    res.add(c);
                    
                    cliente=res.get(0);
                }
                
            } catch (Exception e) {
                System.out.println(e);
            }
        }
       return cliente;
    }
    
    public Cliente buscarCliPorLog(Cliente cli){
        Cliente cliente = new Cliente();
        List<Cliente> res = new ArrayList();
       if (connect()) {
            String cypher = "MATCH (c:Cliente) WHERE c.login='"+cli.getLogin()+"' RETURN c.idcliente, c.nombres, c.apellidos, c.tipoid, c.id, c.login, c.password";
            ResultSet rs;
            rs = query(cypher);
            try {
                while (rs.next()) {
                    Cliente c;
                    c = new Cliente(rs.getInt("c.idcliente"), rs.getString("c.nombres"),
                            rs.getString("c.apellidos"),
                            rs.getString("c.tipoid"), 
                            rs.getString("c.id"),
                            rs.getString("c.login"),
                            rs.getString("c.password"));
                    res.add(c);
                    
                    cliente=res.get(0);
                }
                
            } catch (Exception e) {
                System.out.println(e);
            }
            
        }
       return cliente;
    }
    
    public int asignarIdCliente(){
        int id = 0;
        List <Cliente> clientes = new ArrayList<Cliente>();
        clientes=loadClients();
        for(int i=0;i<clientes.size();i++){
           if(id < clientes.get(i).getIdcliente()){
               id=clientes.get(i).getIdcliente();
           }
        }
        id++;
        return id;
    }
}
