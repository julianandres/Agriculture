/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neoHandler;

import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import clases.Vuelo2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mongoHandler.HandCiudad;

/**
 *
 * @author Carlos Andres
 */
public class HandVuel {
        private String host;
    private int port;
    private Connection connection;
    
   public HandVuel() {
        host = "localhost";
        port = 7474;
    }
    
    public HandVuel(String h, int p) {
        host = h;
        port = p;
    }
/********************GET AND SET****************************/
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }
    /********************GET AND SET****************************/
    
        public boolean connect() {
        try {
            Class.forName("org.neo4j.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:neo4j://localhost:7474");
            return true;
        } catch(ClassNotFoundException e) {
            System.out.println(e);
            return false;
        } catch(SQLException e) {
            System.out.println(e);
            return false;
        }
    }
   
    //Cypher
    public ResultSet query(String cypher) {
        try {
            Statement stm = connection.createStatement();
            ResultSet res = stm.executeQuery(cypher);
            return res;
        } catch(SQLException e) {
            return null;
        }
    }
    
    /***************************FUNCIONES******************************/
     public List loadVuelos() {
        List res = new ArrayList();
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
        if (connect()) {
            String cypher = "MATCH (v:Vuelo) RETURN v.idvuelo, v.codigo, v.fecha, v.idciudest, v.idciudor";
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    //Map<String, Object> obj = (Map<String, Object>)rs.getObject("c");
                    //System.out.println("idvuelo:"+rs.getInt("v.idvuelo")+", codigo:"+rs.getInt("v.codigo")+", fecha:"+rs.getString("v.fecha")+", idciudest:"+rs.getString("v.idciudest")+", idciudor:"+rs.getString("v.idciudor"));
                    Vuelo p = new Vuelo(rs.getInt("v.idvuelo"), rs.getInt("v.codigo"), rs.getString("v.fecha"));
                    int a=rs.getInt("v.idciudest");
                    Ciudad c=mon.retornarCiudadId(a);
                    p.setIdciudest(c);
                    p.setIdciudor(mon.retornarCiudadId(rs.getInt("v.idciudor")));                    
                    res.add(p);
                }
                //System.out.println("FIN");
            } catch(SQLException e) {
                System.out.println(e);
            }
        }
        return res;
    }
    
    public void insertVuelo(Vuelo newVuelo) {
        if (connect()) {
            String cypher = "CREATE (v:Vuelo { idvuelo:"+asignarIdVuelo()+", codigo:"+newVuelo.getCodigo()+", fecha:'"+newVuelo.getFecha()+"', idciudest:"+newVuelo.getIdciudest().getIdciudad()+", idciudor:"+newVuelo.getIdciudor().getIdciudad()+"})";
            query(cypher);
        }
    }
    
    public void updateVuelo(Vuelo vuelo) {
        if (connect()) {
            String cypher = "MATCH (v:Vuelo) WHERE v.idvuelo="+vuelo.getIdvuelo()+" SET v.fecha='"+vuelo.getFecha()+"', v.idciudest="+vuelo.getIdciudest().getIdciudad()+", v.idciudor="+vuelo.getIdciudor().getIdciudad()+" RETURN c";
            query(cypher);
        }
    }
    
    public void deleteVuelo(Vuelo vuelo) {
        if (connect()) {
            //Si hay relaciones entre nodos
            //MATCH (n { name: 'Andres' })-[r]-() DELETE n, r
            String cypher = "MATCH (v:Vuelo) WHERE v.idvuelo="+vuelo.getIdvuelo()+" DELETE v";
            query(cypher);
        }
    }
/*    
public List vueloAsig( Ciudad ori, Ciudad dest, Cliente c){
        List res = new ArrayList();
        if (connect ()){
            String cypher ="MATCH (c)-[r:reserva]->(v) WHERE r.idcliente="+c.getIdcliente()+", r.idvuelo.idciudest="+dest.getIdciudad()+", r.idvuelo.idciudor="+ori.getIdciudad()+" RETURN r" ;
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    Reserva r;
                    r = formarReserva(rs.getInt("r.idcliente"),rs.getInt("r.idvuelo"));
                    r.setIdreserva(rs.getInt("r.idreserva"));
                    res.add(r);
                }
            }catch(Exception e){
                        System.out.println(e);
                        }            
        }
        return res;
    }
    
    public List vueloNoAsig(Ciudad ori, Ciudad dest, Cliente c){
       List res = new ArrayList();
       if (connect ()){
           //match(c: cliente) where c.idcliente <> 1 return c
            String cypher ="MATCH (c)-[r:Reserva]->(v) WHERE r.idcliente <> "+c.getIdcliente()+", r.idvuelo.idciudest <> "+dest.getIdciudad()+", r.idvuelo.idciudor <> "+ori.getIdciudad()+" RETURN r" ;
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    Reserva r;
                    r = formarReserva(rs.getInt("r.idcliente"),rs.getInt("r.idvuelo"));
                    r.setIdreserva(rs.getInt("r.idreserva"));
                    res.add(r);
                }
            }catch(Exception e){
                        System.out.println(e);
                        }            
        }
        return res;
    }
    */
    public Vuelo buscarVueloPorId(int id){
        Vuelo vuelo= new Vuelo();
        List<Vuelo> res = new ArrayList<Vuelo>();
        HandCiudad handciudad = new HandCiudad("localhost", 27017, "turismo");
            handciudad.createConnection();
            handciudad.selectCollection("ciudad");
        if (connect()) {
            String cypher = "MATCH (v:Vuelo) WHERE v.idvuelo="+id+" RETURN v.idvuelo, v.codigo, v.fecha, v.idciudest, v.idciudor";
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    Vuelo p = new Vuelo(rs.getInt("v.idvuelo"), rs.getInt("v.codigo"), rs.getString("v.fecha"));                   
                    Ciudad ciu=handciudad.retornarCiudadId(rs.getInt("v.idciudest"));
                    p.setIdciudest(ciu);
                    p.setIdciudor(handciudad.retornarCiudadId(rs.getInt("v.idciudor")));
                    res.add(p);
                    vuelo=res.get(0);    
                }
            }catch(Exception e){
                        System.out.println(e);
                        } 
            
        }
    
    return vuelo;
    }
    public Reserva formarReserva(int idcliente,int idvuelo) {
        
        HandVuel handv=new HandVuel();
        HandClient handc=new HandClient();        
        
        Reserva res = new Reserva();
        Cliente c = new Cliente();
        Vuelo v = new Vuelo();
        c.setIdcliente(idcliente);
        c=handc.buscarCliPorId(c);
        v=handv.buscarVueloPorId(idvuelo);
        res.setIdcliente(c);
        res.setIdvuelo(v);
        return res;
    }
    
    public List<Vuelo> buscarPorCiudades(Ciudad ciudor,Ciudad ciudest){
    List<Vuelo> vuelos=new ArrayList<Vuelo>();
    HandCiudad handciudad = new HandCiudad("localhost", 27017, "turismo");
            handciudad.createConnection();
            handciudad.selectCollection("ciudad");
    if (connect()) {
            
            String cypher = "MATCH (v:Vuelo) WHERE v.idciudor = "+ciudor.getIdciudad()+
                    " AND v.idciudest = "+ciudest.getIdciudad()+" return v.idvuelo, v.codigo, v.fecha, v.idciudest, v.idciudor";
            ResultSet rs = query(cypher);
            try {
                while(rs.next()) {
                    Vuelo p = new Vuelo(rs.getInt("v.idvuelo"), rs.getInt("v.codigo"), rs.getString("v.fecha"));                   
                    p.setIdciudest(handciudad.retornarCiudadId(rs.getInt("v.idciudest")));
                    p.setIdciudor(handciudad.retornarCiudadId(rs.getInt("v.idciudor")));
                    vuelos.add(p);    
                }
            }catch(Exception e){
                        System.out.println(e);
                        } 
            
        }
    return vuelos;
    }
    
    /***************************FUNCIONES******************************/
    public int asignarIdVuelo(){
        int id = 0;
        List <Vuelo> vuelos = new ArrayList();
        vuelos=loadVuelos();
        for(int i=0;i<vuelos.size();i++){
           if(id < vuelos.get(i).getIdvuelo()){
               id=vuelos.get(i).getIdvuelo();
           }
        }
        id++;
        return id;
    }
}
