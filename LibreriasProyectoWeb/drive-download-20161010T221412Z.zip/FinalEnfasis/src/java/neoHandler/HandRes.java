/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neoHandler;

import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mongoHandler.HandCiudad;

/**
 *
 * @author FredyMauricio
 */
public class HandRes {

    private String host;
    private int port;
    private Connection connection;

    public HandRes() {
        host = "localhost";
        port = 7474;
    }

    public HandRes(String h, int p) {
        host = h;
        port = p;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean connect() {
        try {
            Class.forName("org.neo4j.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:neo4j://localhost:7474");
            return true;
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            return false;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    //Cypher
    public ResultSet query(String cypher) {
        try {
            Statement stm = connection.createStatement();
            ResultSet res = stm.executeQuery(cypher);
            return res;
        } catch (SQLException e) {
            return null;
        }
    }

    public List<Reserva> loadReservas() {
        List<Reserva> res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (r:Reserva) RETURN r";
            ResultSet rs = query(cypher);
            try {
                while (rs.next()) {
                    Reserva r;
                    r = formarReserva(rs.getInt("r.idcliente"), rs.getInt("r.idvuelo"));
                    r.setIdreserva(rs.getInt("idreserva"));
                    res.add(r);
                }
                //System.out.println("FIN");
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
        return res;
    }

    public void insertReserva(Reserva reserva) {
        if (connect()) {
            String cypher = "MATCH (v:Vuelo) WHERE v.idvuelo=" + reserva.getIdvuelo().getIdvuelo()
                    + " MATCH (c:Cliente) WHERE c.idcliente=" + reserva.getIdcliente().getIdcliente()
                    + " CREATE ((v)-[r:Reserva{idreserva:"+asignarIdReserva()+", idvuelo:" + reserva.getIdvuelo().getIdvuelo()
                    + ",idcliente:" + reserva.getIdcliente().getIdcliente() + "}]->(c))";
            //MATCH (v:Vuelo) WHERE v.idvuelo=1 MATCH (c:Cliente) WHERE c.idcliente=2 CREATE ((v)-[:Reserva{idreserva:2, idvuelo:1,idcliente:2}]->(c))
            query(cypher);
        }
    }
    public void eliminarReserva(Reserva res){
        if (connect()) {
            String cypher = "MATCH (c) -[r:Reserva]-> (v) WHERE r.idreserva= " +res.getIdreserva()+" DELETE r";
            query(cypher);
    
        }
    }

    public List buscarReservaPorCliente(Cliente cliente) {
        List res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (c) -[r:Reserva]-> (v) WHERE r.idcliente=" + cliente.getIdcliente()+" RETURN r.idreserva,r.idcliente,r.idvuelo";
            ResultSet rs;
            rs = query(cypher);
            try {
                while (rs.next()) {
                    System.out.println(rs.getInt("r.idcliente"));
                    System.out.println(rs.getInt("r.idreserva"));
                    Reserva r=formarReserva(rs.getInt("r.idcliente"), rs.getInt("r.idvuelo"));                   
                    r.setIdreserva(rs.getInt("r.idreserva"));
                    res.add(r);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return res;
    }

    public boolean buscarReservaPorClienteYVuelo(Cliente cliente, Vuelo vuelo) {
        List res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (c) -[r:Reserva]-> (v) WHERE r.idcliente=" + cliente.getIdcliente() + " AND r.idvuelo = " + vuelo.getIdvuelo()+" RETURN r";//TRAER LOS VUELOS CON LAS CIUDADES SELECCIONADAD
            //MATCH (c)-[r:Reserva]-> (v) WHERE r.idcliente = 2 AND r.idvuelo = 1 return r
            ResultSet rs;
            rs = query(cypher);
            try {
                if(rs.next()){
                 return true;
                }else{
                 return false;
                }
                
                
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return false;
    }
    public Reserva busReservaPorClienteYVuelo(Cliente cliente, Vuelo vuelo) {
        List<Reserva> res = new ArrayList();
        Reserva rese=new Reserva();
        if (connect()) {
            String cypher = "MATCH (c) -[r:Reserva]-> (v) WHERE r.idcliente=" + cliente.getIdcliente() + " AND r.idvuelo = " + vuelo.getIdvuelo()+" RETURN r.idreserva,r.idvuelo,r.idcliente";//TRAER LOS VUELOS CON LAS CIUDADES SELECCIONADAD
            //MATCH (c)-[r:Reserva]-> (v) WHERE r.idcliente = 2 AND r.idvuelo = 1 return r
            ResultSet rs;
            rs = query(cypher);
            try{
              while(rs.next()){
                 Reserva r=formarReserva(rs.getInt("r.idcliente"), rs.getInt("r.idvuelo"));                   
                 r.setIdreserva(rs.getInt("r.idreserva"));
                 res.add(r);              
              }
              rese=res.get(0);                
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return rese;
    }
    public Reserva formarReserva(int idcliente,int idvuelo) {
        
        HandVuel handv=new HandVuel();
        HandClient handc=new HandClient();        
        
        Reserva res = new Reserva();
        Cliente c = new Cliente();
        Vuelo v = new Vuelo();
        c.setIdcliente(idcliente);
        c=handc.buscarCliPorId(c);
        v=handv.buscarVueloPorId(idvuelo);
        res.setIdcliente(c);
        res.setIdvuelo(v);
        return res;
    }
    public int asignarIdReserva(){
        int id = 0;
        List <Reserva> reservas = new ArrayList<Reserva>();
        reservas=loadReservas();
        for(int i=0;i<reservas.size();i++){
           if(id < reservas.get(i).getIdreserva()){
               id=reservas.get(i).getIdreserva();
           }
        }
        id++;
        return id;
    }
}

