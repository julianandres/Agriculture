/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mongoHandler;


import clases.Administrador;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

/**
 *
 * @author javhur
 */
public class HandAdmin {
    private String host;
    private int port;
    private String dbname;
    private DB db;
    private DBCollection collection;

    public HandAdmin() {
       host="localhost";
       port=27017;
       String dbname="turismo";
    }

    public HandAdmin(String h, int p) {
        host = h;
        port = p;
    }
    
    public HandAdmin(String h, int p, String d) {
        host = h;
        port = p;
        dbname = d;
    }
    
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getDbname() {
        return dbname;
    }

    public void setDbname(String dbname) {
        this.dbname = dbname;
    }

    public DB getDb() {
        return db;
    }

    public void setDb(DB db) {
        this.db = db;
    }

    public DBCollection getCollection() {
        return collection;
    }

    public void setCollection(DBCollection collection) {
        this.collection = collection;
    }

    public DB createConnection() {
        try {
            MongoClient mongo = new MongoClient(host, port);
            db = mongo.getDB(dbname);
            return db;
        } catch(UnknownHostException e) {
            return null;
        }
    }
    
    public DBCollection selectCollection(String coll) {
        collection = db.getCollection(coll);
        return collection;
    }
    
    public List createElement(String field, Object value) {
        ArrayList f = new ArrayList();
        f.add(field);
        f.add(value);
        return f;
    }
    
    public BasicDBObject createDocument(List data) {
        BasicDBObject doc = new BasicDBObject();
        for (Object d: data) {
            List l = (List)d;
            doc.append((String)l.get(0), l.get(1));
        }
        return doc;
    }
    
    public void insertDocument(BasicDBObject doc) {
        collection.insert(doc);
    }
    
    public Administrador retornarAdminLogin(String login){
     Administrador admin = null;
      ArrayList res = new ArrayList();
       DBObject query = new BasicDBObject("login", login);
      DBCursor cursor = collection.find(query);
       while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            ObjectId id=(ObjectId) obj.get("_id");
            System.out.println(id);
            Administrador c = new Administrador((ObjectId)obj.get("_id"),(String)obj.get("nombres"),(String)obj.get("apellidos"), (String)obj.get("login"), (String)obj.get("password"));
            res.add(c);
            admin=(Administrador) res.get(0);
        }
    return admin;
    }
    
}
