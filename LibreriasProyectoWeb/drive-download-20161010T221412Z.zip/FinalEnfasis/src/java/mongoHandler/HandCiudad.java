/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mongoHandler;


import clases.Administrador;
import clases.Ciudad;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

/**
 *
 * @author javhur
 */
public class HandCiudad {
    private String host;
    private int port;
    private String dbname;
    private DB db;
    private DBCollection collection;

    public HandCiudad() {
       host="localhost";
       port=27017;
       String dbname="turismo";
    }

    public HandCiudad(String h, int p) {
        host = h;
        port = p;
    }
    
    public HandCiudad(String h, int p, String d) {
        host = h;
        port = p;
        dbname = d;
    }
    
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getDbname() {
        return dbname;
    }

    public void setDbname(String dbname) {
        this.dbname = dbname;
    }

    public DB getDb() {
        return db;
    }

    public void setDb(DB db) {
        this.db = db;
    }

    public DBCollection getCollection() {
        return collection;
    }

    public void setCollection(DBCollection collection) {
        this.collection = collection;
    }

    public DB createConnection() {
        try {
            MongoClient mongo = new MongoClient(host, port);
            db = mongo.getDB(dbname);
            return db;
        } catch(UnknownHostException e) {
            return null;
        }
    }
    
    public DBCollection selectCollection(String coll) {
        collection = db.getCollection(coll);
        return collection;
    }
    
    public List createElement(String field, Object value) {
        ArrayList f = new ArrayList();
        f.add(field);
        f.add(value);
        return f;
    }
    
    public BasicDBObject createDocument(List data) {
        BasicDBObject doc = new BasicDBObject();
        for (Object d: data) {
            List l = (List)d;
            doc.append((String)l.get(0), l.get(1));
        }
        return doc;
    }
    
    public void insertDocument(BasicDBObject doc) {
        WriteResult res=collection.insert(doc);
    }
     public void editCiudad(Ciudad ciudad) {
        BasicDBObject docnew = new BasicDBObject();
        docnew.put("nombre",ciudad.getNombre());
        docnew.put("idciudad",ciudad.getIdciudad());
        docnew.put("pageweb",ciudad.getPageweb());
        BasicDBObject docold= new BasicDBObject();
        docold.put("idciudad",ciudad.getIdciudad());
        collection.update(docold, docnew);
    }
    public Ciudad retornarCiudadNombre(String nombre){
     Ciudad ciu =null;
      ArrayList res = new ArrayList();
       DBObject query = new BasicDBObject("nombre", nombre);
      DBCursor cursor = collection.find(query);
       while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            Ciudad c= new Ciudad((ObjectId)obj.get("_id"),(int)obj.get("idciudad"),(String)obj.get("nombre"), (String)obj.get("pageweb"));
            res.add(c);
            ciu=(Ciudad) res.get(0);
        }
    return ciu;
    }
    public Ciudad retornarCiudadId(int id){
     Integer a= new Integer(id);
     Ciudad ciu =new Ciudad();
       ArrayList<Ciudad> res= obtenerCiudades();
       for(int i=0;i<res.size();i++){
           if(res.get(i).getIdciudad()==id){
             ciu=res.get(i);
           }
       }
     /* DBCursor cursor = collection.find(query);
       while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            Ciudad c= new Ciudad((ObjectId)obj.get("_id"),(int)obj.get("idciudad"),(String)obj.get("nombre"), (String)obj.get("pageweb"));
            res.add(c);
            ciu=(Ciudad) res.get(0);
        }*/
    return ciu;
    }
    public void eliminarCiudad(Ciudad ciudad){
        BasicDBObject docold= new BasicDBObject();
        docold.put("idciudad",ciudad.getIdciudad());
        collection.remove(docold);    
    }
    public ArrayList<Ciudad> obtenerCiudades() {
        ArrayList<Ciudad> res = new ArrayList<Ciudad>();
        DBCursor cursor = collection.find();
        while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            Ciudad c = new Ciudad((ObjectId)obj.get("_id"),(int)obj.get("idciudad"),(String)obj.get("nombre"), (String)obj.get("pageweb"));
            res.add(c);
        }
        return res;
    }
      public int asignarIdCiudad(){
        int id = 0;
        List <Ciudad> ciudades = new ArrayList<Ciudad>();
        ciudades=obtenerCiudades();
        for(int i=0;i<ciudades.size();i++){
           if(id < ciudades.get(i).getIdciudad()){
               id=ciudades.get(i).getIdciudad();
           }
        }
        id++;
        return id;
    }
    
}