/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import clases.Administrador; 
import mongoHandler.HandAdmin;
import clases.Cliente;
import java.io.Serializable;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class AdminEJB implements Serializable{
    
    
    public Administrador buscarAdministradorPorLogin(Administrador p) {
       HandAdmin mon = new HandAdmin("localhost", 27017, "turismo");
        mon.createConnection();
        mon.selectCollection("administrador");

        Administrador administrador = new Administrador();
        try {
            administrador = mon.retornarAdminLogin(p.getLogin()); ;
        } catch (javax.persistence.NoResultException e) {
            return null;
        }
        return administrador;
    }
}
