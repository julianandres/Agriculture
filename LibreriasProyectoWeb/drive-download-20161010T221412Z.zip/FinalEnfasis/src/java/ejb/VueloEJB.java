/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.Query;
import neoHandler.HandRes;
import neoHandler.HandVuel;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class VueloEJB implements Serializable {
    private HandVuel neo = new HandVuel();
    private List<Vuelo> listaReservados;
    private List<Vuelo> listaNoReservados;

    public List<Vuelo> getListaReservados() {
        return listaReservados;
    }

    public void setListaReservados(List<Vuelo> listaReservados) {
        this.listaReservados = listaReservados;
    }

    public List<Vuelo> getListaNoReservados() {
        return listaNoReservados;
    }

    public void setListaNoReservados(List<Vuelo> listaNoReservados) {
        this.listaNoReservados = listaNoReservados;
    }

     public boolean crearVuelo(Vuelo vuelo) {
        try {
            neo.insertVuelo(vuelo);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
     public boolean editarVuelo(Vuelo p) {
        try {
            neo.updateVuelo(p);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public boolean eliminarVuelo(Vuelo p) {
        try {
            neo.deleteVuelo(p);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public List<Vuelo> obtenerVuelos() {
        List<Vuelo> vuelos = new ArrayList<Vuelo>();
        try {
            vuelos = neo.loadVuelos();
        } catch (javax.persistence.NoResultException e) {
            return null;
        }
        return vuelos;
    }
    public List<Vuelo> buscarVuelosAsigPorCiudades(Ciudad ori,Ciudad dest,Cliente c) {
        llenarListasVuelos(ori, dest, c);
        return listaReservados;
    }
    public List<Vuelo> buscarVuelosNoAsigPorCiudades(Ciudad ori,Ciudad dest,Cliente c) {        
        llenarListasVuelos(ori, dest, c);
        return listaNoReservados;
    } 
    public void llenarListasVuelos(Ciudad ori,Ciudad dest,Cliente c){
        HandVuel hv= new HandVuel();
        HandRes hr=new HandRes();
        List<Reserva> reservas = new ArrayList<Reserva>();        
        List<Vuelo> vuelos = new ArrayList<Vuelo>();
        List<Vuelo> vueloCiu=new ArrayList<Vuelo>();
        vueloCiu=hv.buscarPorCiudades(ori, dest);
        listaNoReservados=new ArrayList<Vuelo>();
        listaReservados=new ArrayList<Vuelo>();
        for(int i=0; i<vueloCiu.size();i++){
           if(hr.buscarReservaPorClienteYVuelo(c, vueloCiu.get(i))){
               listaReservados.add(vueloCiu.get(i));
           }else{
               listaNoReservados.add(vueloCiu.get(i));       
           } 
        }
    }
}
