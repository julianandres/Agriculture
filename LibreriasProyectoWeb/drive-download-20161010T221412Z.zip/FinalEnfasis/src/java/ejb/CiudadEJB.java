/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import com.mongodb.BasicDBObject;
import clases.Ciudad;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import mongoHandler.HandCiudad;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class CiudadEJB implements Serializable {

  
    
    public boolean crearCiudad(Ciudad ciudad) {
        try {
            //System.out.println(prof.getApellidos()+"\n"+p.getIdentificacion()+"\n"+p.getNombres()+"\n"+p.getProfesion());
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
            BasicDBObject doc = new BasicDBObject();  
            doc.put("idciudad",asignarIdCiudad());
            doc.put("nombre",ciudad.getNombre());
            doc.put("pageweb",ciudad.getPageweb());
            mon.insertDocument(doc);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
     public boolean editarCiudad(Ciudad p) {
        try {
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
            mon.editCiudad(p);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
    public boolean eliminarCiudad(Ciudad p) {
        try {
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
            mon.eliminarCiudad(p);            
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public List<Ciudad> obtenerCiudades() {
        List<Ciudad> ciudades = new ArrayList<Ciudad>();
        try {
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
            ciudades = mon.obtenerCiudades();
        } catch (Exception e) {
            return null;
        }
        return ciudades;
    }
     public Ciudad buscarCiudadPorNombre(String nom) {
        
        Ciudad ciudad=new Ciudad();
        try {
            HandCiudad mon = new HandCiudad("localhost", 27017, "turismo");
            mon.createConnection();
            mon.selectCollection("ciudad");
            ciudad = mon.retornarCiudadNombre(nom);
        } catch (Exception e) {
            return null;
        }
        return ciudad;
    }
      public int asignarIdCiudad(){
        int id = 0;
        List <Ciudad> ciudades = new ArrayList<Ciudad>();
        ciudades=obtenerCiudades();
        for(int i=0;i<ciudades.size();i++){
           if(id < ciudades.get(i).getIdciudad()){
               id=ciudades.get(i).getIdciudad();
           }
        }
        id++;
        return id;
        }
}
