/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import neoHandler.HandClient;
import neoHandler.HandRes;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class ReservaEJB implements Serializable {
    private HandRes neo = new HandRes();
     public boolean crearReserva(Reserva reserva) {
        try {
            neo.insertReserva(reserva);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
     public List<Reserva> buscarReservaPorCliente(Cliente p) {
         List<Reserva> reservas = new ArrayList<Reserva>();
        try {
            reservas = neo.buscarReservaPorCliente(p);
        } catch (Exception e) {
            return null;
        }
        return reservas;
    }
     public Reserva buscarReservaPorClienteYVuelo(Cliente p,Vuelo v) {
         Reserva reserva=new Reserva();
        try {
         reserva=neo.busReservaPorClienteYVuelo(p, v);
        } catch (Exception e) {
            return null;
        }
        return reserva;
    }
      public boolean eliminarReserva(Reserva r) {
        try {
          neo.eliminarReserva(r);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    
}
