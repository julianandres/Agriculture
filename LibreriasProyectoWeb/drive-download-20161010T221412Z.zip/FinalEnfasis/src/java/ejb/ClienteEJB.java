/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejb;

import clases.Cliente;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import neoHandler.HandClient;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class ClienteEJB implements Serializable {

   private HandClient neo = new HandClient();
    
    public boolean crearCliente(Cliente cliente) {
        try {
           neo.insertCliente(cliente);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
     public boolean editarCliente(Cliente p) {
        try {
            neo.updateCliente(p);//ponia en el contexto de persistencia y actualizaba
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public boolean eliminarCliente(Cliente p) {
        try {
            neo.deleteCliente(p);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public List<Cliente> obtenerClientes() {
        List<Cliente> clientes = new ArrayList<Cliente>();
        try {
            clientes=neo.loadClients();
        } catch (Exception e) {
            return null;
        }
        return clientes;
    }
    public Cliente buscarClientePorIdentificacion(Cliente p) {
        Cliente cliente=new Cliente();
        try {
            cliente = neo.buscarCliPorId(p);
        } catch (Exception e) {
            return null;
        }
        return cliente;
    }
     public Cliente buscarClientePorLogin(Cliente p) {
         Cliente cliente=new Cliente();
        try {
            cliente = neo.buscarCliPorLog(p);
        } catch (Exception e) {
            return null;
        }
        return cliente;
    }    
}
