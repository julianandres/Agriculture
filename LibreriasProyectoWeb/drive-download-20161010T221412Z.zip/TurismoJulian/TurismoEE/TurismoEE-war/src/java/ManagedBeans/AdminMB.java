/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ManagedBeans;

import ejb.AdminEJB;
import ejb.CiudadEJB;
import ejb.ClienteEJB;
import ejb.ReservaEJB;
import ejb.VueloEJB;
import clases.Administrador;
import clases.Ciudad;
import clases.Cliente;
import clases.Vuelo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.model.SelectItem;

/**
 *
 * @author ju
 */
@ManagedBean
@SessionScoped
public class AdminMB implements Serializable{

    @EJB
    private ClienteEJB cliEJB;
    @EJB
    private AdminEJB admiEJB;
    @EJB
    private CiudadEJB ciuEJB;
    @EJB
    private VueloEJB vuelEJB;
    private String msg = "";
    private Administrador admin;
    private List<Cliente> clientes;
    private List<Vuelo> vuelos;
    private List<Ciudad> ciudades;
    private HtmlDataTable dataTableCli;
    private HtmlDataTable dataTableVuel;
    private HtmlDataTable dataTableCiud;
    private Cliente client;
    private Ciudad ciudad;
    private Vuelo vuel;

    public boolean isValidate() {
        return validate;
    }

    public void setValidate(boolean validate) {
        this.validate = validate;
    }

    public Vuelo getVuel() {
        return vuel;
    }

    public void setVuel(Vuelo vuel) {
        this.vuel = vuel;
    }
    private List<SelectItem> ciudList;
    private List<SelectItem> tipoIds;
    private Cliente cliente;
    private String ciudOrSelect;
    private String ciudDeSelect;
    private Ciudad ciuOr;
    private Ciudad ciuDest;
    private boolean validate;


    public Ciudad getCiuOr() {
        return ciuOr;
    }

    public void setCiuOr(Ciudad ciuOr) {
        this.ciuOr = ciuOr;
    }

    public Ciudad getCiuDest() {
        return ciuDest;
    }

    public void setCiuDest(Ciudad ciuDest) {
        this.ciuDest = ciuDest;
    }

    public String getCiudOrSelect() {
        return ciudOrSelect;
    }

    public void setCiudOrSelect(String ciudOrSelect) {
        this.ciudOrSelect = ciudOrSelect;
    }

    public String getCiudDeSelect() {
        return ciudDeSelect;
    }

    public void setCiudDeSelect(String ciudDeSelect) {
        this.ciudDeSelect = ciudDeSelect;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<SelectItem> getTipoIds() {
        return tipoIds;
    }

    public void setTipoIds(List<SelectItem> tipoIds) {
        this.tipoIds = tipoIds;
    }

    public List<SelectItem> getCiudList() {
        return ciudList;
    }

    public void setCiudList(List<SelectItem> ciudList) {
        this.ciudList = ciudList;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }

    public void setCiudad(Ciudad ciudad) {
        this.ciudad = ciudad;
    }

    public Cliente getClient() {
        return client;
    }

    public void setClient(Cliente client) {
        this.client = client;
    }

    public HtmlDataTable getDataTableVuel() {
        return dataTableVuel;
    }

    public void setDataTableVuel(HtmlDataTable dataTableVuel) {
        this.dataTableVuel = dataTableVuel;
    }

    public HtmlDataTable getDataTableCli() {
        return dataTableCli;
    }

    public void setDataTableCli(HtmlDataTable dataTableCli) {
        this.dataTableCli = dataTableCli;
    }

    public HtmlDataTable getDataTableCiud() {
        return dataTableCiud;
    }

    public void setDataTableCiud(HtmlDataTable dataTableCiud) {
        this.dataTableCiud = dataTableCiud;
    }

    public List<Vuelo> getVuelos() {
        return vuelos;
    }

    public void setVuelos(List<Vuelo> vuelos) {
        this.vuelos = vuelos;
    }

    public List<Ciudad> getCiudades() {
        return ciudades;
    }

    public void setCiudades(List<Ciudad> ciudades) {
        this.ciudades = ciudades;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Administrador getAdmin() {
        return admin;
    }

    public void setAdmin(Administrador admin) {
        this.admin = admin;
    }

    public String mostrarLoginAdmin() {
        admin = new Administrador();
        msg = "";
        return "loginAdmin.xhtml";
    }

    public String validarAdmin() {
        System.out.println(admin.getPassword());
        String password = admin.getPassword();

        admin = admiEJB.buscarAdministradorPorLogin(admin);
        if (admin == null) {
            validate=false;
            msg = "Password o login incorrectos";
            return "errorAdmin.xhtml";

        } else {
            if (admin.getPassword().equals(password)) {
                validate = true;
                return "inicioAdministrador.xhtml";
            } else {
                validate=false;
                msg = "Password o login incorrectos";
                return "errorAdmin.xhtml";
            }
        }
    }

    public String mostrarListarClientes() {
        clientes = new ArrayList<Cliente>();
        clientes = cliEJB.obtenerClientes();
        return "listarClientes.xhtml";
    }

    public String mostrarListarVuelos() {
        vuelos = new ArrayList<Vuelo>();
        vuelos = vuelEJB.obtenerVuelos();
        return "listarVuelos.xhtml";
    }

    public String mostrarListarCiudades() {
        ciudades = new ArrayList<Ciudad>();
        ciudades = ciuEJB.obtenerCiudades();
        return "listarCiudades.xhtml";
    }

    public String mostrarCrearClientes() {
        client = new Cliente();
        tipoIds = new ArrayList<SelectItem>();
        tipoIds.add(new SelectItem("C.C"));
        tipoIds.add(new SelectItem("T.I"));
        return "crearCliente.xhtml";
    }

    public String mostrarEditarCliente() {
        msg = "";
        client = (Cliente) dataTableCli.getRowData();
        return "editarClientes.xhtml";
    }

    public String mostrarEliminarCliente() {
        msg = "";
        client = new Cliente();
        client = (Cliente) dataTableCli.getRowData();
        return "eliminarClientes.xhtml";
    }

    public String mostrarCrearCiudad() {
        ciudad = new Ciudad();
        return "crearCiudad.xhtml";
    }

    public String mostrarCrearVuelo() {
        vuel = new Vuelo();
        ciudList = new ArrayList<SelectItem>();
        ciudades = new ArrayList<Ciudad>();
        ciudades = ciuEJB.obtenerCiudades();
        for (int i = 0; i < ciudades.size(); i++) {
            String nom = ciudades.get(i).getNombre();
            ciudList.add(new SelectItem(nom));
        }
        return "createVuelo.xhtml";
    }

    public String mostrarEditarVuelos() {
        msg = "";
        vuel = (Vuelo) dataTableVuel.getRowData();
        ciudList = new ArrayList<SelectItem>();
        ciudades = new ArrayList<Ciudad>();
        ciudades = ciuEJB.obtenerCiudades();
        for (int i = 0; i < ciudades.size(); i++) {
            String nom = ciudades.get(i).getNombre();
            ciudList.add(new SelectItem(nom));
        }
        return "editarVuelos.xhtml";
    }

    public String mostrarEliminarVuelos() {
        msg = "";
        vuel = (Vuelo) dataTableVuel.getRowData();
        return "eliminarVuelos.xhtml";
    }

    public String mostrarEditarCiudad() {
        msg = "";
        ciudad = (Ciudad) dataTableCiud.getRowData();
        return "editarCiudades.xhtml";
    }

    public String mostrarEliminarCiudad() {
        msg = "";
        ciudad = (Ciudad) dataTableCiud.getRowData();
        return "eliminarCiudades.xhtml";
    }

    public String crearCliente() {
        if (cliEJB.crearCliente(client)) {
            msg = "Cliente Creado";
            clientes = cliEJB.obtenerClientes();
        } else {
            msg = "Error al crear Cliente";
        }

        return "gestionClientes.xhtml";
    }

    public String editarCliente() {
        if (cliEJB.editarCliente(client)) {
            msg = "Cliente Editado";
            clientes = cliEJB.obtenerClientes();
        } else {
            msg = "Error al editar Cliente";
        }

        return "gestionClientes.xhtml";
    }

    public String eliminarCliente() {
        if (cliEJB.eliminarCliente(client)) {
            msg = "Cliente Eliminado";
            clientes = cliEJB.obtenerClientes();
        } else {
            msg = "Error al eliminar Cliente";
        }
        return "gestionClientes.xhtml";
    }

    public String creovuelo() {

        System.out.println("creando vuelo");
        ciuOr = ciuEJB.buscarCiudadPorNombre(ciudOrSelect);
        ciuDest = ciuEJB.buscarCiudadPorNombre(ciudDeSelect);
        vuel.setIdciudest(ciuDest);
        vuel.setIdciudor(ciuOr);
       // System.out.println(vuel.getCodigo()+" fecha  "+ vuel.getFecha()+ " ciudDest "+vuel.getIdciudest().getNombre()
        // +" ciudor "+ vuel.getIdciudor().getNombre()+ " ");
        if (vuelEJB.crearVuelo(vuel)) {
            msg = "Vuelo Creado";
            vuelos = vuelEJB.obtenerVuelos();
        } else {
            msg = "Error al crear Vuelo";
        }

        return "gestionarVuelos.xhtml";
    }

    public String editarVuelos() {
        ciuOr = ciuEJB.buscarCiudadPorNombre(ciudOrSelect);
        ciuDest = ciuEJB.buscarCiudadPorNombre(ciudDeSelect);
        vuel.setIdciudest(ciuDest);
        vuel.setIdciudor(ciuOr);
       // System.out.println(vuel.getCodigo()+" fecha  "+ vuel.getFecha()+ " ciudDest "+vuel.getIdciudest().getNombre()
        // +" ciudor "+ vuel.getIdciudor().getNombre()+ " ");
        if (vuelEJB.editarVuelo(vuel)) {
            msg = "Vuelo editado";
            vuelos = vuelEJB.obtenerVuelos();
        } else {
            msg = "Error al editar Vuelo";
        }

        return "gestionarVuelos.xhtml";
    }

    public String eliminarVuelos() {
        if (vuelEJB.eliminarVuelo(vuel)) {
            msg = "Vuelo Eliminado";
            vuelos = vuelEJB.obtenerVuelos();
        } else {
            msg = "Error al eliminar Vuelo";
        }
        return "gestionarVuelos.xhtml";
    }

    public String crearCiudad() {
        System.out.println(ciudad.getNombre());
        System.out.println(ciudad.getPageweb());
        if (ciuEJB.crearCiudad(ciudad)) {
            msg = "Ciudad Creada";
            ciudades = ciuEJB.obtenerCiudades();
        } else {
            msg = "Error al crear Ciudad";
        }

        return "gestionCiudades.xhtml";
    }

    public String editarCiudad() {
        System.out.println(ciudad.getNombre());
        System.out.println(ciudad.getPageweb());
        if (ciuEJB.editarCiudad(ciudad)) {
            msg = "Ciudad Editada";
            ciudades = ciuEJB.obtenerCiudades();
        } else {
            msg = "Error al editar Ciudad";
        }

        return "gestionCiudades.xhtml";
    }

    public String eliminarCiudad() {
        System.out.println(ciudad.getNombre());
        System.out.println(ciudad.getPageweb());
        if (ciuEJB.eliminarCiudad(ciudad)) {
            msg = "Ciudad eliminada";
            ciudades = ciuEJB.obtenerCiudades();
        } else {
            msg = "Error al eliminar Ciudad";
        }

        return "gestionCiudades.xhtml";
    }

    public AdminMB() {
    }

    public String cerrarSesion() {
        validate = false;
        return "index.xhtml";
    }
}
