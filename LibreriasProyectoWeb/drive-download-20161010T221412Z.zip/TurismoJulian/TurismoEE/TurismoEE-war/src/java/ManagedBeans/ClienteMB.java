/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ManagedBeans;

import ejb.CiudadEJB;
import ejb.ClienteEJB;
import ejb.ReservaEJB;
import ejb.VueloEJB;
import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

/**
 *
 * @author ju
 */
@ManagedBean
@SessionScoped
public class ClienteMB implements Serializable{

    @EJB
    private ClienteEJB cliEJB;
    @EJB
    private ReservaEJB resEJB;
    @EJB
    private CiudadEJB ciuEJB;
    @EJB
    private VueloEJB vuelEJB;
    private String msg = "";
    private String pwd;
    private List<Reserva> reservas;
    private List<Ciudad> ciudades;
    private HtmlDataTable dataTableRes;
    private HtmlDataTable dataTableVuel;
    private HtmlDataTable dataTableVuelAs;
    private HtmlDataTable dataTableVuelNoAs;
    private String ciudOrSelect;
    private String ciudDeSelect;
    private Ciudad ciuOr;
    private Ciudad ciuDest;
    private List<Vuelo> vuelos;
    private List<Vuelo> vuelosAsig;
    private List<Vuelo> vuelosNoAsig;
    private List<SelectItem> ciudList;
    private Reserva resSel;
    private Vuelo vuelo;
    private boolean validate;

    public boolean isValidate() {
        return validate;
    }

    public void setValidate(boolean validate) {
        this.validate = validate;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Reserva getResSel() {
        return resSel;
    }

    public void setResSel(Reserva resSel) {
        this.resSel = resSel;
    }

    public HtmlDataTable getDataTableVuelAs() {
        return dataTableVuelAs;
    }

    public void setDataTableVuelAs(HtmlDataTable dataTableVuelAs) {
        this.dataTableVuelAs = dataTableVuelAs;
    }

    public HtmlDataTable getDataTableVuelNoAs() {
        return dataTableVuelNoAs;
    }

    public void setDataTableVuelNoAs(HtmlDataTable dataTableVuelNoAs) {
        this.dataTableVuelNoAs = dataTableVuelNoAs;
    }

    public List<Vuelo> getVuelosAsig() {
        return vuelosAsig;
    }

    public void setVuelosAsig(List<Vuelo> vuelosAsig) {
        this.vuelosAsig = vuelosAsig;
    }

    public List<Vuelo> getVuelosNoAsig() {
        return vuelosNoAsig;
    }

    public void setVuelosNoAsig(List<Vuelo> vuelosNoAsig) {
        this.vuelosNoAsig = vuelosNoAsig;
    }

    public HtmlDataTable getDataTableVuel() {
        return dataTableVuel;
    }

    public void setDataTableVuel(HtmlDataTable dataTableVuel) {
        this.dataTableVuel = dataTableVuel;
    }

    public List<Vuelo> getVuelos() {
        return vuelos;
    }

    public void setVuelos(List<Vuelo> vuelos) {
        this.vuelos = vuelos;
    }

    public Ciudad getCiuOr() {
        return ciuOr;
    }

    public void setCiuOr(Ciudad ciuOr) {
        this.ciuOr = ciuOr;
    }

    public Ciudad getCiuDest() {
        return ciuDest;
    }

    public void setCiuDest(Ciudad ciuDest) {
        this.ciuDest = ciuDest;
    }

    public String getCiudDeSelect() {
        return ciudDeSelect;
    }

    public void setCiudDeSelect(String ciudDeSelect) {
        this.ciudDeSelect = ciudDeSelect;
    }
    

    public List<SelectItem> getCiudList() {
        return ciudList;
    }

    public void setCiudList(List<SelectItem> ciudList) {
        this.ciudList = ciudList;
    }

    public List<Ciudad> getCiudades() {
        return ciudades;
    }

    public void setCiudades(List<Ciudad> ciudades) {
        this.ciudades = ciudades;
    }

    public String getCiudOrSelect() {
        return ciudOrSelect;
    }

    public void setCiudOrSelect(String ciudSelect) {
        this.ciudOrSelect = ciudSelect;
    }

    public HtmlDataTable getDataTableRes() {
        return dataTableRes;
    }

    public void setDataTableRes(HtmlDataTable dataTableRes) {
        this.dataTableRes = dataTableRes;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(List<Reserva> reservas) {
        this.reservas = reservas;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }
    private String log;

    public ClienteMB() {
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    private Cliente client;

    public Cliente getClient() {
        return client;
    }

    public void setClient(Cliente client) {
        this.client = client;
    }

    public String mostrarLoginCliente() {
        client = new Cliente();
        msg = "";

        return "logClient.xhtml";
    }

    public String validarCliente() {
        System.out.println(client.getPassword());
        String password = client.getPassword();

        client = cliEJB.buscarClientePorLogin(client);
        if (client == null) {
            msg = "Password o login incorrectos";
            validate=false;
            return "errorCliente.xhtml";

        } else {
            if (client.getPassword().equals(password)) {
                validate=true;
                return "inicioCliente.xhtml";
            } else {
                validate=false;
                msg = "Password o login incorrectos";
                return "errorCliente.xhtml";
            }
        }
    }

    public String mostrarListarReservas() {
        reservas = new ArrayList<Reserva>();
        reservas = resEJB.buscarReservaPorCliente(client);
        return "listarReservas.xhtml";
    }

    public String mostrarGestionarReservas() {
         ciudades = new ArrayList<Ciudad>();
        ciudList = new ArrayList<SelectItem>();
        vuelosAsig = new ArrayList<Vuelo>();
        vuelosNoAsig = new ArrayList<Vuelo>();
        ciuOr = ciuEJB.buscarCiudadPorNombre(ciudOrSelect);
        ciuDest = ciuEJB.buscarCiudadPorNombre(ciudDeSelect);

        ciudades = ciuEJB.obtenerCiudades();
        for (int i = 0; i < ciudades.size(); i++) {
            String nom = ciudades.get(i).getNombre();
            ciudList.add(new SelectItem(nom));
        }
        return "gestionarReservas.xhtml";
    }

    public String mostrarGestionarReservasTablas() {

        ciudades = new ArrayList<Ciudad>();
        ciudList = new ArrayList<SelectItem>();
        vuelosAsig = new ArrayList<Vuelo>();
        vuelosNoAsig = new ArrayList<Vuelo>();
        ciuOr = ciuEJB.buscarCiudadPorNombre(ciudOrSelect);
        ciuDest = ciuEJB.buscarCiudadPorNombre(ciudDeSelect);
        System.out.println(ciuOr.getNombre() + " destino");
        System.out.println(ciuDest.getNombre() + " origen");
        vuelosAsig = vuelEJB.buscarVuelosAsigPorCiudades(ciuOr, ciuDest, client);
        vuelosNoAsig = vuelEJB.buscarVuelosNoAsigPorCiudades(ciuOr, ciuDest, client);
        
        
        try {
            System.out.println(vuelosAsig.size());
        } catch (Exception e) {
            // System.out.println("llego vaciiaa");
        }
        try {
            System.out.println(vuelosAsig.size());
        } catch (Exception e) {
            //System.out.println("llego vacia 23 4");
        }
        ciudades = ciuEJB.obtenerCiudades();
        for (int i = 0; i < ciudades.size(); i++) {
            String nom = ciudades.get(i).getNombre();
            ciudList.add(new SelectItem(nom));
        }
        return "gestionarReservasTablas.xhtml";
    }

    public String eliminarReserva() {
        vuelo = new Vuelo();
        vuelo = (Vuelo) dataTableVuelAs.getRowData();
        System.out.println(vuelo.getCodigo() + " este es el codigo del vuelo seleccionado");
        resSel = resEJB.buscarReservaPorClienteYVuelo(client, vuelo);
        if (resSel != null) {
            resEJB.eliminarReserva(resSel);
        } else {
            System.out.println("no hay que eliminar");
        }

        String page = mostrarGestionarReservasTablas();
        return page;
    }

    public String reservar() {
        vuelo = new Vuelo();
        Reserva res = new Reserva();
        vuelo = (Vuelo) dataTableVuelNoAs.getRowData();
        res.setIdvuelo(vuelo);
        res.setIdcliente(client);
        resEJB.crearReserva(res);
        return mostrarGestionarReservasTablas();
    }
    public void irAWebOr(){
       ciuOr = ciuEJB.buscarCiudadPorNombre(ciudOrSelect);
        String url="http://"+ciuOr.getPageweb();
       FacesContext fc=FacesContext.getCurrentInstance();
       
        try {
            fc.getExternalContext().redirect(url);
        } catch (IOException ex) {
            System.out.println("error");
        }
    }
    public void irAWebDes(){
    
       ciuDest = ciuEJB.buscarCiudadPorNombre(ciudDeSelect);
        String url="http://"+ciuDest.getPageweb();
        FacesContext fc=FacesContext.getCurrentInstance();
       
        try {
            fc.getExternalContext().redirect(url);
        } catch (IOException ex) {
            System.out.println("error");
        }
    }
    public String cerrarSesion(){
    validate=false;
      dataTableRes=null;
      dataTableVuel=null;
     dataTableVuelAs=null;
     dataTableVuelNoAs=null;
     validate=false;
     
    return "index.xhtml";
    }
}
