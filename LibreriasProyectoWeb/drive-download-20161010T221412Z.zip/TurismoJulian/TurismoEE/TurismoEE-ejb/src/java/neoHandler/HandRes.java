/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neoHandler;

import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mongoHandler.HandCiudad;

/**
 *
 * @author FredyMauricio
 */
public class HandRes {

    private String host;
    private int port;
    private Connection connection;

    public HandRes() {
        host = "localhost";
        port = 7474;
    }

    public HandRes(String h, int p) {
        host = h;
        port = p;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean connect() {
        try {
            Class.forName("org.neo4j.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:neo4j://localhost:7474");
            return true;
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            return false;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    //Cypher
    public ResultSet query(String cypher) {
        try {
            Statement stm = connection.createStatement();
            ResultSet res = stm.executeQuery(cypher);
            return res;
        } catch (SQLException e) {
            return null;
        }
    }

    public List<Reserva> loadReservas() {
        List<Reserva> res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (r:Reserva) RETURN r.idreserva";
            ResultSet rs = query(cypher);
            try {
                while (rs.next()) {
                    Reserva r;
                    r = new Reserva(rs.getShort("r.idreserva"));
                    res.add(r);
                }
                //System.out.println("FIN");
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
        return res;
    }

    public void insertReserva(Reserva reserva) {
        if (connect()) {
            String cypher = "MATCH (v:Vuelo) WHERE v.idvuelo=" + reserva.getIdvuelo().getIdvuelo()
                    + "' MATCH (c:Cliente) WHERE c.idcliente=" + reserva.getIdcliente().getIdcliente()
                    + "' CREATE (v)-[:Reserva{idreserva:"+asignarIdReserva()+", idvuelo:" + reserva.getIdvuelo().getIdvuelo()
                    + ",idcliente:" + reserva.getIdcliente().getIdcliente() + "}]->(c)";
            query(cypher);
        }
    }

    public List buscarReservaPorCliente(Cliente cliente) {
        List res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (c:Cliente) -[r:reserva]-> (v:Vuelo) WHERE r.idcliente=" + cliente.getIdcliente();
            ResultSet rs;
            rs = query(cypher);
            try {
                while (rs.next()) {
                    Reserva r;
                    r = new Reserva(rs.getShort("r.idcliente"));
                    res.add(r);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return res;
    }

    public List buscarReservaPorClienteYVuelo(Cliente cliente, Vuelo vuelo) {
        List res = new ArrayList();
        if (connect()) {
            String cypher = "MATCH (c:Cliente) -[r:reserva]-> (v:Vuelo) WHERE r.idcliente=" + cliente.getIdcliente() + " AND r.idvuelo = " + vuelo.getIdvuelo();
            ResultSet rs;
            rs = query(cypher);
            try {
                while (rs.next()) {
                    Reserva r;                   
                    r = formarReserva(rs.getInt("r.idcliente"), rs.getInt("r.idvuelo"));
                    res.add(r);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return res;
    }

    public void deleteCliente(Cliente cliente) {
        if (connect()) {
            //Si hay relaciones entre nodos
            //MATCH (n { name: 'Andres' })-[r]-() DELETE n, r
            String cypher = "MATCH (c:Ciudad) WHERE c.code=" + cliente.getIdcliente() + " DELETE c";
            query(cypher);
        }
    }

    public Cliente buscarCliPorId(Cliente cli) {
        Cliente cliente = new Cliente();
        if (connect()) {
            String cypher = "MATCH (c:Cliente) WHERE c.idcliente=" + cliente.getIdcliente();
            cliente = (Cliente) query(cypher);
        }
        return cliente;
    }

    public Cliente buscarCliPorLog(Cliente cli) {
        Cliente cliente = new Cliente();
        if (connect()) {
            String cypher = "MATCH (c:Cliente) WHERE c.login='" + cliente.getLogin() + "'";
            cliente = (Cliente) query(cypher);
        }
        return cliente;
    }

    public Reserva formarReserva(int idcliente,int idvuelo) {
        
        HandVuel handv=new HandVuel();
        HandClient handc=new HandClient();        
        
        Reserva res = new Reserva();
        Cliente c = new Cliente();
        Vuelo v = new Vuelo();
        c.setIdcliente(idcliente);
        c=handc.buscarCliPorId(c);
        v=handv.buscarVueloPorId(idvuelo);
        res.setIdcliente(c);
        res.setIdvuelo(v);
        return res;
    }
    public int asignarIdReserva(){
        int id = 0;
        List <Reserva> reservas = new ArrayList<Reserva>();
        reservas=loadReservas();
        for(int i=0;i<reservas.size();i++){
           if(id < reservas.get(i).getIdreserva()){
               id=reservas.get(i).getIdreserva();
           }
        }
        id++;
        return id;
    }
}

