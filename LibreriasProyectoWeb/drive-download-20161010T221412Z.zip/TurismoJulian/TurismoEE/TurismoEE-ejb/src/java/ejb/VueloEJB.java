/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejb;

import clases.Ciudad;
import clases.Cliente;
import clases.Reserva;
import clases.Vuelo;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.Query;
import neoHandler.HandVuel;

/**
 *
 * @author ju
 */
@Stateless
@LocalBean
public class VueloEJB {
    private HandVuel neo = new HandVuel();
    private List<Vuelo> lista;

     public boolean crearVuelo(Vuelo vuelo) {
        try {
            neo.insertVuelo(vuelo);
            lista = neo.loadVuelos();
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
     public boolean editarVuelo(Vuelo p) {
        try {
            neo.updateVuelo(p);
            lista = neo.loadVuelos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public boolean eliminarVuelo(Vuelo p) {
        try {
            neo.deleteVuelo(p);
            lista = neo.loadVuelos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public List<Vuelo> obtenerVuelos() {
        List<Vuelo> vuelos = new ArrayList<Vuelo>();
        try {
            vuelos = neo.loadVuelos();
        } catch (javax.persistence.NoResultException e) {
            return null;
        }
        return vuelos;
    }
    public List<Vuelo> buscarVuelosAsigPorCiudades(Ciudad ori,Ciudad dest,Cliente c) {
        List<Reserva> reservas = new ArrayList<Reserva>();        
        List<Vuelo> vuelos = new ArrayList<Vuelo>();
        try {
            reservas = neo.vueloAsig(ori, dest, c);
            for(int i=0;i<reservas.size();i++)
            {
              vuelos.add(reservas.get(i).getIdvuelo());
            }             
        } catch (Exception e) {
            return null;
        }
        return vuelos;
    }
    public List<Vuelo> buscarVuelosNoAsigPorCiudades(Ciudad ori,Ciudad dest,Cliente c) {        
        List<Reserva> reservas = new ArrayList<Reserva>();        
        List<Vuelo> vuelos = new ArrayList<Vuelo>();
        try {
            reservas = neo.vueloNoAsig(ori, dest, c);
            for(int i=0;i<reservas.size();i++)
            {
              vuelos.add(reservas.get(i).getIdvuelo());
            }             
        } catch (Exception e) {
            return null;
        }
        return vuelos;
    } 
}
